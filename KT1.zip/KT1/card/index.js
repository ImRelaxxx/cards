const phones = [
  {
    id: 1,
    name: "Apple iPhone 14 Pro 512GB Gold",
    model: "(MQ2T3)",
    price: '$1437',
    image: "./images/gold.png"
  },
  {
    id: 2,
    name: "Apple iPhone 11 128GB White",
    model: "(MQ233)",
    price: '$510',
    image: "./images/white.png"
  },
  {
    id: 3,
    name: "Apple iPhone 11 128GB White",
    model: "(MQ233)",
    price:'$550',
    image: "./images/white.png"
  },
  {
    id: 4,
    name: "Apple iPhone 14 Pro 1TB Gold",
    model: "(MQ2V3)",
    price: '$1499',
    image: "./images/gold1.png"
  },
  {
    id: 5,
    name: "Apple iPhone 14 Pro 1TB Gold",
    model: "(MQ2V3)",
    price: '$1399',
    image: "./images/gold.png"
  },
  {
    id: 6,
    name: "Apple iPhone 14 Pro 128GB Deep Purple",
    model: "(MQ0G3)",
    price: '$1600',
    image: "./images/purple.png"
  },
  {
    id: 7,
    name: "Apple iPhone 13 mini 128GB Pink",
    model: "(MLK23)",
    price: '$850',
    image: "./images/pink.png"
  },
  {
    id: 8,
    name: "Apple iPhone 14 Pro 256GB Space Black",
    model: "(MQ0T3)",
    price: '$1399',
    image: "./images/black.png"
  },
  {
    id: 9,
    name: "Apple iPhone 14 Pro 256GB Silver",
    model: "(MQ103)",
    price: '$1399',
    image: "./images/silver.png"
  }
];

const container = document.querySelector(".container")

for (let i = 0; i < 9; i++) {
    const cardHTML = `<div class="card">
        <div class="heart"><img style="position: relative; left: 85%; cursor: pointer;" src="./images/Favorite_duotone.png" alt=""></div>
        <div class="card_top">
            <img src="${phones[i].image}" alt="">
        </div>

        <div class="card_bottom">

            <span class="description">
                ${phones[i].name + ' ' + phones[i].model}
            </span>
            <span class="price">
                ${phones[i].price }
            </span>

            <button class="btn">Buy now</button>
    </div>`;
    
    container.innerHTML += cardHTML
    
}